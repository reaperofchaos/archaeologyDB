<?php

require_once('../../private/initialize.php');

	$args =[];
	//Post variables 
	isset($_POST['title'])
		? $args['title'] = $_POST['title']
		: $args['title'] = null;
	if(!empty($_POST['author'])){
		$authors = [];
		foreach($_POST['author'] as $a){
			if($a != ''){
				array_push($authors, $a);
			}
		}
		$args['authors'] = $authors;
	} else{
		$args['authors'] = [];
	}
	isset($_POST['year'])
		? $args['year'] = $_POST['year']
		: $args['year'] = null;
	isset($_POST['journal'])
		? $args['journal'] = $_POST['journal']
		: $args['journal'] = null;
	isset($_POST['volume'])
		? $args['volume'] = $_POST['volume']
		: $args['volume'] = null;
	isset($_POST['issue'])
		? $args['issue'] = $_POST['issue']
		: $args['issue'] = null;
	!empty($_FILES['srcLocation'])
		? $file = $_FILES['srcLocation']
		: $file = null;
	print_r($args);
	//create new article object
	$article = new Article($args);
	echo "<br />
		Article Object: <br />";
	print_r(var_dump($article));
	echo "<br />";
	$exists = Article::checkIfSrcExists($article);
	echo "<br />
		Exists Object: <br />";
	print_r(var_dump($exists));
	echo "<br />";	
	if(!$exists){
		Article::insertAuthors($article);
		if($file != null){
			Article::uploadArticle($article, $file);
			print_r(var_dump($article));
			echo "<br />";
		}
		Article::insert($article);
	}else{
		$update = [];
		if ($exists[0]->title != $article->title){
			$update['title'] = $args['title'];
		}
		if ($exists[0]->year != $article->year){
			$update['year'] = $args['year'];
		}
		if ($exists[0]->journal != $article->journal){
			$update['journal'] = $args['journal'];
		}
		if ($exists[0]->volume != $article->volume){
			$update['volume'] = $args['volume'];
			
		}
		if ($exists[0]->issue != $article->issue){
			$update['issue'] = $args['issue'];
		}
		print_r($update);
		if(!empty($update)){
			Article::updateSource($exists[0], $update);
			foreach($update as $key => $value) {
				$attribute_pairs[] = "{$key}='{$value}'";
			  }		
			echo 'The article '. $exists[0]->title . ' already exists. '
			.$exists[0]->srcType . " - " . $exists[0]->srcId . '<br />
			Updated ' . join(' <br />', $attribute_pairs); 
		}else{	
			echo 'Form Handling Error: <br />
			Could not add article. The article '. $exists[0]->title . ' already exists. '
			.$exists[0]->srcType . " - " . $exists[0]->srcId;
		}
	}
	
?>