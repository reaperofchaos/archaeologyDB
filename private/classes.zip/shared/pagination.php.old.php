<?php require_once('../private/initialize.php'); ?>

<?php $total = Article::count_sources(); ?>
<?php
$adjacents = 3;
$targetpage = $_SERVER['PHP_SELF']; //your file name
$limit = 50; //how many items to show per page
if(isset($_GET['page'])){
    $page = $_GET['page'];
}else{
    $page = 0;
}

if($page){ 
    $start = ($page - 1) * $limit; //first item to display on this page
}else{
    $start = 0;
}
/* Setup page vars for display. */
    if ($page == 0){
        $page = 1; //if no page var is given, default to 1.
    } 
    $prev = $page - 1; //previous page is current page - 1
    $next = $page + 1; //next page is current page + 1
    $lastpage = ceil($total/$limit); //lastpage.
    $lpm1 = $lastpage - 1; //last page minus 1
?>
    <?php $article_name = Article::find_all_source_by_limit($start, $limit); ?>
<?php
    $pagination = "";
    $counter = 0;
?>

<?php 
//check if more than 1 page, sets up a previous
if($lastpage > 1)
    { ?>
        <ul class='pagination'>
        <?php if($page > $counter + 1){ ?>
            <li><a href="<?php echo $targetpage; ?>?page=<?php echo $prev; ?>"><</a></li>
        <?php } ?>
<?php 
//check if less than 7 entries
    if ($lastpage < 7 + ($adjacents * 2)) 
    { 
        for ($counter = 1; $counter <= $lastpage; $counter++)
        {
            if ($counter == $page){
?>
                <li class='active'><a href='#' ><?php echo $counter; ?></a></li>
<?php 
            }else{ ?>
                <li><a href="<?php echo $targetpage; ?>?page=<?php echo $counter; ?>"><?php echo $counter; ?></a></li> 
 <?php      }
        }
   // check if greater than 5 entries
    } elseif($lastpage > 5 + ($adjacents * 2)){
?>
        <li><a href="<?php echo $targetpage; ?>?page=1">1</a></li>
        <li><a href="<?php echo $targetpage; ?>?page=2">2</a></li>
        <li>...</li>
<?php 
            for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
            {
                if ($counter == $page){ ?>
                    <li class='active'><a href='#' ><?php echo $counter; ?></a></li>
<?php           }else{ ?>
                    <li><a href="<?php echo $targetpage; ?>?page=<?php echo $counter; ?>"><?php echo $counter; ?></a></li>
<?php           } ?>

                <li>...</li>
                <li><a href="<?php echo $targetpage; ?>?page=<?php echo $lpm1; ?>"><?php echo $lpm1; ?></a></li>
                <li><a href="<?php echo $targetpage; ?>?page=<?php echo $lastpage; ?>"><?php echo $lastpage; ?></a></li> 
<?php        } 
        //close to end; only hide early pages
    }else{ ?>
                <li><a href="<?php echo $targetpage; ?>?page=1">1</a></li>
                <li><a href="<?php echo $targetpage; ?>?page=2">2</a></li>
                <li>...</li>
<?php    for($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; 
            $counter++)
            {
                if ($counter == $page){ ?>
                    <li class='active'><a href='#'><?php echo $counter; ?></a></li>
<?php           }else{ ?>
                    <li><a href="<?php echo $targetpage; ?>?page=<?php echo $counter; ?>"><?php echo $counter; ?></a></li>
<?php           } 
            }
        } ?>

<?php  //next button
    if ($page < $counter - 1){ ?>
        <li><a href="<?php echo $targetpage; ?>?page=<?php echo $next; ?>">></a></li>
    <?php }else{ ?>
        </ul>
<?php   }
} ?>