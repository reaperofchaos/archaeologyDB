<?php

require_once('../../private/initialize.php');

	$args =[];
	//Post variables 
	isset($_POST['title'])
		? $args['title'] = $_POST['title']
		: $args['title'] = null;
	if(!empty($_POST['author'])){
		$authors = [];
		foreach($_POST['author'] as $a){
			if($a != ''){
				array_push($authors, $a);
			}
		}
		$args['authors'] = $authors;
	} else{
		$args['authors'] = [];
    }
    if(!empty($_POST['editor'])){
		$editors = [];
		foreach($_POST['editor'] as $e){
			if($a != ''){
				array_push($editors, $e);
			}
		}
		$args['editors'] = $editors;
	} else{
		$args['editors'] = [];
	}
	isset($_POST['year'])
		? $args['year'] = $_POST['year']
		: $args['year'] = null;
	isset($_POST['publisher'])
		? $args['publisher'] = $_POST['publisher']
		: $args['publisher'] = null;
	isset($_POST['location'])
		? $args['location'] = $_POST['location']
		: $args['location'] = null;
	!empty($_FILES['srcLocation'])
		? $file = $_FILES['srcLocation']
		: $file = null;
	print_r($args);
	//create new article object
	$book = new Book($args);
	echo "<br />
		Book Object: <br />";
	print_r(var_dump($book));
	echo "<br />";
	$exists = Book::checkIfSrcExists($book);
	echo "<br />
		Exists Object: <br />";
	print_r(var_dump($exists));
	echo "<br />";	
	if(!$exists){
		Book::insert_authors($book);
		if($file != null){
			Book::uploadBook($book, $file);
			print_r(var_dump($article));
			echo "<br />";
		}
		Book::insertBook($book);
	}else{
		$update = [];
		if ($exists[0]->title != $book->title){
			$update['title'] = $args['title'];
		}
		if ($exists[0]->year != $book->year){
			$update['year'] = $args['year'];
		}
		if ($exists[0]->publisher != $book->publisher){
			$update['publisher'] = $args['publisher'];
		}
		if ($exists[0]->location != $book->location){
			$update['location'] = $args['location'];
		}
		print_r($update);
		if(!empty($update)){
			Book::updateBook($exists[0], $update);
			foreach($update as $key => $value) {
				$attribute_pairs[] = "{$key}='{$value}'";
			  }		
			echo 'The book '. $exists[0]->title . ' already exists. '
			.$exists[0]->srcType . " - " . $exists[0]->srcId . '<br />
			Updated ' . join(' <br />', $attribute_pairs); 
		}else{	
			echo 'Form Handling Error: <br />
			Could not add book. The book '. $exists[0]->title . ' already exists. '
			.$exists[0]->srcType . " - " . $exists[0]->srcId;
		}
	}
	
?>