<?php

    function createCitation($source, $citation, $srcType, $srcId){
        echo "<table class='table table-bordered'>
                    <thead class='thead-inverse'>
                        <tr>
                            <th>ID</th>
                            <th>Article</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <input type='hidden' class='src_id' id='". $srcType . "-". $srcId . "' name='src_id' value='". $srcType . "-". $srcId . "' />" .
                                $srcType . "-" . $srcId .
                            "</td>
                            <td>" . $citation .
                            "</td>
                            <td>
                                <a href='jomon/";
                                if(!empty($source->srcLocation)){
                                    echo $source->srcLocation;
                                }else {
                                    echo ""; 
                                }
                            echo "'>English</a>";
                                if(!empty($source->website)){
                                    echo "<a href='" . $source->website . "' target='_blank'>Website</a>";
                                }
                        echo "</td>
                        </tr>
                    </tbody>
                </table>";
                //print_r(var_dump($source));
               // echo Source::createSourcePreview($source);
        }            

    function createRecord($srcType, $srcId){
        $chapterCitation = "";
        switch($srcType){
            case 'a':
                $source = Article::findById($srcType, $srcId); 
                Article::getAuthors($source, $srcType, $srcId);
                $citation = Article::createCitation($source); 
                break;
            case 'ab':
                $source = Summary::find_by_id($srcType, $srcId); 
                Summary::get_authors($source, $srcType, $srcId);
                $citation = Summary::create_citation($source);
                break;
            case 'b':
                $source = Book::find_by_id($srcType, $srcId); 
                Book::get_authors($source, $srcType, $srcId);
                Book::get_editors($source, $srcType, $srcId);
                $citation = Book::create_citation($source); 
                $chapterCitation = Book::createChapterCitation($source);
                break;
            case 'd':
                $source = Dissertation::find_by_id($srcType, $srcId); 
                Dissertation::get_authors($source, $srcType, $srcId);
                Dissertation::get_supervisors($source, $srcType, $srcId);
                $citation = Dissertation::create_citation($source);
                break;
            case 'po':
                $source = Poster::find_by_id($srcType, $srcId); 
                Poster::get_presenters($source, $srcType, $srcId);
                $citation = Poster::create_citation($source);
                break;
            case 'pr':
                $source = Presentation::find_by_id($srcType, $srcId); 
                Presentation::get_presenters($source, $srcType, $srcId);
                $citation = Presentation::create_citation($source);
                break;
            case 'r':
                $source = Radio::find_by_id($srcType, $srcId); 
                Radio::get_presenters($source, $srcType, $srcId);
                $citation = Radio::create_citation($source);
                break;
            case 't':
                $source = Thesis::find_by_id($srcType, $srcId); 
                Thesis::get_authors($source, $srcType, $srcId);
                Thesis::get_supervisors($source, $srcType, $srcId);
                $citation = Thesis::create_citation($source);
                break;
            case 'v':
                $source = Video::find_by_id($srcType, $srcId); 
                Video::get_creators($source, $srcType, $srcId);
                Video::get_uploaders($source, $srcType, $srcId);
                $citation = Video::create_citation($source);
                break;
            case 'w':
                $source = Website::find_by_id($srcType, $srcId);
                Website::get_webmasters($source, $srcType, $srcId);
                $citation = Website::create_citation($source);
                break;
            default:
        }
        createCitation($source, $citation, $srcType, $srcId);
        if($chapterCitation != ""){
            echo $chapterCitation;
        }
    }
?>     