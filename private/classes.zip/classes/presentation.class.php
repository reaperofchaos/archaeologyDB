<?php
    class Presentation extends Source {
        //constructor
        public $date;
        public $location; 
        public $website; 
        public $conference; 
        public $presenters; 

        public function __construct($args=[]) {
                parent::__construct($args);  
                $this->date = $args['date'] ?? '';
                $this->location = $args['location'] ?? '';
                $this->website = $args['website'] ?? '';
                $this->conference = $args['conference'] ?? '';
                $this->presenters = [];
        }

        static public function find_by_sql($sql) {
                $result = self::$database->prepare($sql);
                $result->execute();
                
                if(!$result) {
                exit("Database query failed.");
                }
                $result->setFetchMode(PDO::FETCH_ASSOC); 
                // results into objects
                $object_array = [];
                while($record = $result->fetch()) {
                $object_array[] = self::instantiate($record);
                }  
                $result=null;
                return $object_array;
        }

        static protected function instantiate($record) {
                $object = new self;
                // Could manually assign values to properties
                // but automatically assignment is easier and re-usable
                foreach($record as $property => $value) {
                if(property_exists($object, $property)) {
                    $object->$property = $value;
                }
                }
                return $object;
        }

        static public function find_by_id($srcType, $srcId) {
                $query = "SELECT * ";
                $query .= " FROM sources";
                $query .= " INNER JOIN authors";
                $query .= " ON authors.source_id = sources.srcId";
                $query .= " INNER JOIN conference";
                $query .= " ON conference.conf_id = sources.conferenceId";
                $query .= " WHERE srcId='" . $srcId . "'";
                $query .= " AND srcType='" . $srcType . "'";
                $obj_array = self::find_by_sql($query);
                if(!empty($obj_array)) {
                    return array_shift($obj_array);
                } else {
                    return false;
                }
        }

        static public function get_presenters($source, $srcType, $srcId){
            $presenters =[];
            $sql = "SELECT * ";
            $sql .= "FROM authors ";
            $sql .= "WHERE source_id = '" . $srcId . "'";
            $sql .= " AND source_type= '" . $srcType . "'";
            $sql .= " AND author_type= 'presenter'";
            $result = self::$database->prepare($sql);
            $result->execute();
            
            if(!$result) {
                exit("Database query failed.");
            }
            $result->setFetchMode(PDO::FETCH_ASSOC); 
            while($record = $result->fetch()) {
                array_push($presenters, $record['author_name']);
            }
            $source->presenters = $presenters;
        }

        static public function create_citation($presentation){  
            $citation = "";
            
            if(!empty($poster->presenters)){
        	$presenters =$presentation->presenters;
        	$i = 1;
        	$length = count($presenters);
        	foreach($presenters as $a){
        		if($i == $length){
         			$citation .= $a . ". ";
         		}else{
         			$citation .= $a . ", ";
         			}
         				$i++;
        	}
        }
            !empty($presentation->date) ?  $citation .= $presentation->date . ". " : null;
            !empty($presentation->title) ?$citation .= $presentation->title . ". " : null;
            !empty($presentation->conference) ? $citation .= "Presented at " . $presentation->conference : null;
            !empty($presentation->location) ? $citation .= "(" . $presentation->location . ")" : null;
            return $citation;
        } 
    }
?>