<?php
    class Dissertation extends Source{
        //constructor
        public $date;
        public $level; 
        public $location; 
        public $authors;
        

        public function __construct($args=[]) {
                parent::__construct($args);  
                $this->date = $args['date'] ?? '';
                $this->location = $args['location'] ?? '';
                $this->level = $args['level'] ?? '';
                $this->authors = [];
        }

        static public function find_by_sql($sql) {
                $result = self::$database->prepare($sql);
                $result->execute();
                
                if(!$result) {
                exit("Database query failed.");
                }
                $result->setFetchMode(PDO::FETCH_ASSOC); 
                // results into objects
                $object_array = [];
                while($record = $result->fetch()) {
                $object_array[] = self::instantiate($record);
                }  
                $result=null;
                return $object_array;
        }

        static protected function instantiate($record) {
                $object = new self;
                // Could manually assign values to properties
                // but automatically assignment is easier and re-usable
                foreach($record as $property => $value) {
                if(property_exists($object, $property)) {
                    $object->$property = $value;
                }
                }
                return $object;
        }

        static public function find_by_id($srcType, $srcId) {
                $query = "SELECT * ";
                $query .= " FROM sources";
                $query .= " INNER JOIN authors";
                $query .= " ON authors.source_id = sources.srcId";
                $query .= " WHERE srcId='" . $srcId . "'";
                $query .= " AND srcType='" . $srcType . "'";
                $obj_array = self::find_by_sql($query);
                if(!empty($obj_array)) {
                    return array_shift($obj_array);
                } else {
                    return false;
                }
        }
        static public function get_authors($source, $srcType, $srcId){
            $authors =[];
            $sql = "SELECT * ";
            $sql .= "FROM authors ";
            $sql .= "WHERE source_id = '" . $srcId . "'";
            $sql .= " AND source_type= '" . $srcType . "'";
            $sql .= " AND author_type = 'author'";
        
            $result = self::$database->prepare($sql);
            $result->execute();
              
            if(!$result) {
                exit("Database query failed.");
              }
              $result->setFetchMode(PDO::FETCH_ASSOC); 
                while($record = $result->fetch()) {
                    array_push($authors, $record['author_name']);
                }
            $source->authors = $authors;
        }
        
        static public function get_supervisors($source, $srcType, $srcId){
            $supervisors =[];
            $sql = "SELECT * ";
            $sql .= "FROM authors ";
            $sql .= "WHERE source_id = '" . $srcId . "'";
            $sql .= " AND source_type= '" . $srcType . "'";
            $sql .= " AND author_type = 'supervisor'";
        
            $result = self::$database->prepare($sql);
            $result->execute();
              
            if(!$result) {
                exit("Database query failed.");
            }
            $result->setFetchMode(PDO::FETCH_ASSOC); 
            while($record = $result->fetch()) {
                array_push($supervisors, $record['author_name']);
            }
            $source->supervisors = $supervisors;
        }
        static public function create_citation($dissertation){  
            $citation = "";
            if(!empty($dissertation->authors)){
                $authors =$dissertation->authors;
                $i = 1;
                $length = count($authors);
                foreach($authors as $a){
                    if($i == $length){
                        $citation .= $a . ". ";
                    }else{
                        $citation .= $a . ", ";
                        }
                            $i++;
                }
            }
            if(!empty($dissertation->supervisors)){
                $supervisors =$dissertation->supervisors;
                $i = 1;
                $length = count($supervisors);
                $citation .= "Supervised by ";
                foreach($supervisors as $a){
                    if($i == $length){
                        $citation .= $a . ". ";
                    }else{
                        $citation .= $a . ", ";
                        }
                            $i++;
                }
            }
            !empty($dissertation->date) ?  $citation .= $dissertation->date . ". " : null;
            !empty($dissertation->title) ?$citation .= $dissertation->title . ". " : null;
            !empty($dissertation->level) ? $citation .= $dissertation->level : null;
            !empty($dissertation->location) ? $citation .= " ( Completed at " . $dissertation->location . ")" : null;
            return $citation;
        } 
    }
?>