<?php
    class Video extends Source{
        
             //constructor
             public $date;
             public $website; 
             public $creators;
             public $uploader;
     
             public function __construct($args=[]) {
                     parent::__construct($args);  
                     $this->date = $args['date'] ?? '';
                     $this->website = $args['website'] ?? '';
                     $this->author = $args['author'] ?? '';
                     $this->creators = [];
                     $this->uploaders = [];
             }
     
             static public function find_by_sql($sql) {
                     $result = self::$database->prepare($sql);
                     $result->execute();
                     
                     if(!$result) {
                     exit("Database query failed.");
                     }
                     $result->setFetchMode(PDO::FETCH_ASSOC); 
                     // results into objects
                     $object_array = [];
                     while($record = $result->fetch()) {
                     $object_array[] = self::instantiate($record);
                     }  
                     $result=null;
                     return $object_array;
             }
     
             static protected function instantiate($record) {
                     $object = new self;
                     // Could manually assign values to properties
                     // but automatically assignment is easier and re-usable
                     foreach($record as $property => $value) {
                     if(property_exists($object, $property)) {
                         $object->$property = $value;
                     }
                     }
                     return $object;
             }
     
             static public function find_by_id($srcType, $srcId) {
                     $query = "SELECT * ";
                     $query .= " FROM sources";
                     $query .= " INNER JOIN authors";
                     $query .= " ON authors.source_id = sources.srcId";
                     $query .= " WHERE srcId='" . $srcId . "'";
                     $query .= " AND srcType='" . $srcType . "'";
                     $obj_array = self::find_by_sql($query);
                     if(!empty($obj_array)) {
                         return array_shift($obj_array);
                     } else {
                         return false;
                     }
             }
             
             static public function get_creators($source, $srcType, $srcId){
                $creators =[];
                $sql = "SELECT * ";
                $sql .= "FROM authors ";
                $sql .= "WHERE source_id = '" . $srcId . "'";
                $sql .= " AND source_type= '" . $srcType . "'";
                $sql .= " AND author_type = 'creator'";
            
                $result = self::$database->prepare($sql);
                $result->execute();
                  
                if(!$result) {
                    exit("Database query failed.");
                }
                $result->setFetchMode(PDO::FETCH_ASSOC); 
                while($record = $result->fetch()) {
                    array_push($creators, $record['author_name']);
                }
                $source->creators = $creators;
            }
            static public function get_uploaders($source, $srcType, $srcId){
                $uploaders =[];
                $sql = "SELECT * ";
                $sql .= "FROM authors ";
                $sql .= "WHERE source_id = '" . $srcId . "'";
                $sql .= " AND source_type= '" . $srcType . "'";
                $sql .= " AND author_type = 'uploader'";
            
                $result = self::$database->prepare($sql);
                $result->execute();
                  
                if(!$result) {
                    exit("Database query failed.");
                }
                $result->setFetchMode(PDO::FETCH_ASSOC); 
                while($record = $result->fetch()) {
                    array_push($uploaders, $record['author_name']);
                }
                $source->uploaders = $uploaders;
            } 
             static public function create_citation($video){  
                $citation = "";
                if(!empty($video->creators)){
                    $creators =$video->creators;
                    $i = 1;
                    $length = count($creators);
                    foreach($creators as $a){
                        if($i == $length){
                            $citation .= $a . ". ";
                        }else{
                            $citation .= $a . ", ";
                            }
                                $i++;
                    }
                }
                if(!empty($video->uploaders)){
                    $creators =$video->uploaders;
                    $i = 1;
                    $length = count($uploaders);
                    $citation = .= "Uploaded by ";
                    foreach($uploaders as $a){
                        if($i == $length){
                            $citation .= $a . ". ";
                        }else{
                            $citation .= $a . ", ";
                            }
                                $i++;
                    }
                }
                !empty($video->date) ?  $citation .= $video->date . ". " : null;
                !empty($video->title) ?$citation .= $video->title . ". " : null;
                !empty($video->website) ? $citation .= " Website: " . $video->website : null;
                 return $citation;
             } 
        
    }
?>