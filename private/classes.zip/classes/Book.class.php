<?php 
    class Book extends Source {
        public $year; 
        public $publisher;
        public $location; 
        public $srcType;
        public $authors;
        public $editors;

        public function __construct($args=[]) {
            parent::__construct($args);
            $this->year = $args['year'] ?? '';
                $this->authorList = $args['author_name'] ?? '';
                $this->editorList = $args['author_name'] ?? '';
                $this->publisher = $args['publisher'] ?? '';
                $this->location = $args['location'] ?? '';
                $this->srcType = $args['srcType'] ?? 'b';
                $this->authors = [];
                $this->editors =[];

        }
        
        static protected function instantiate($record) {
            $object = new self;
            // Could manually assign values to properties
            // but automatically assignment is easier and re-usable
            foreach($record as $property => $value) {
                if(property_exists($object, $property)) {
                    $object->$property = $value;
                }
            }
            return $object;
        }

        static public function find_by_sql($sql) {
            $result = self::$database->prepare($sql);
            $result->execute();
            
            if(!$result) {
                exit("Database query failed.");
            }
            $result->setFetchMode(PDO::FETCH_ASSOC); 
            // results into objects
            $object_array = [];
            while($record = $result->fetch()) {
                $object_array[] = self::instantiate($record);
            }  
            $result=null;
            return $object_array;
        }
        //SQL query
        static public function find_by_id($srcType, $srcId) {
            $query = "SELECT * ";
            $query .= " FROM sources";
            $query .= " INNER JOIN authors";
            $query .= " ON authors.source_id = sources.srcId";
            $query .= " WHERE srcId='" . $srcId . "'";
            $query .= " AND srcType='" . $srcType . "'";
            $query .= " LIMIT 1";
            $obj_array = self::find_by_sql($query);
            if(!empty($obj_array)) {
                return array_shift($obj_array);
            } else {
                return false;
            }
    }
    static public function get_editors($source, $srcType, $srcId){
        $editors =[];
        $sql = "SELECT * ";
        $sql .= "FROM authors ";
        $sql .= "WHERE source_id = '" . $srcId . "'";
        $sql .= " AND source_type= '" . $srcType . "'";
        $sql .= " AND author_type = 'editor'";

         $result = self::$database->prepare($sql);
          $result->execute();
          
          if(!$result) {
            exit("Database query failed.");
          }
          $result->setFetchMode(PDO::FETCH_ASSOC); 
          while($record = $result->fetch()) {
            array_push($editors, $record['author_name']);
        }
        $source->editors = $editors;
    }
    static public function get_authors($source, $srcType, $srcId){
        $authors =[];
        $sql = "SELECT * ";
        $sql .= "FROM authors ";
        $sql .= "WHERE source_id = '" . $srcId . "'";
      $sql .= " AND source_type= '" . $srcType . "'";
      $sql .= " AND author_type = 'author'";
    
         $result = self::$database->prepare($sql);
          $result->execute();
          
          if(!$result) {
            exit("Database query failed.");
          }
          $result->setFetchMode(PDO::FETCH_ASSOC); 
          while($record = $result->fetch()) {
            array_push($authors, $record['author_name']);
        }
        $source->authors = $authors;
    }
        static public function create_citation($book){  
            $citation = "";
            
            !empty($book->editorList) ? $citation .= $book->editorList . "." : null; 
            if(!empty($book->editors)){
        	$editors =$book->editors;
        	$i = 1;
        	$length = count($editors);
        	foreach($editors as $a){
        		if($i == $length){
         			$citation .= $a . " Editors. ";
         		}else{
         			$citation .= $a . ", ";
         			}
         				$i++;
        	}
        }
            if(!empty($book->authors)){
        	$authors =$book->authors;
        	$i = 1;
        	$length = count($authors);
        	foreach($authors as $a){
        		if($i == $length){
         			$citation .= $a . ". ";
         		}else{
         			$citation .= $a . ", ";
         			}
         				$i++;
        	}
        }
            !empty($book->year) ?  $citation .= $book->year . ". " : null;
            !empty($book->title) ?$citation .= $book->title . ". " : null;
            !empty($book->publisher) ? $citation .= $book->publisher : null;
            !empty($book->location) ? $citation .= "(" . $book->location . ")" : null;
            return $citation;
        }

        static public function createChapterCitation($book){  
            $citation = "<h3>Chapters</h3>
                        <br />
                        <table class='table'>
                        <tr>
                        <th>Chapter ID</th>
                        <th>Chapter No</th>
                        <th>Citation</th>
                        <th>Source </th>
                        </tr>";
            if(!empty($book->editors)){
                $editors =$book->editors;
            }else{
                $editors = [];
            }
            $chapters =  Chapter::find_by_id($book->srcType, $book->srcId);
            if(!empty($chapters)){
            foreach ($chapters as $c){
                Chapter::get_authors($c, $c->subSrcType, $c->subSrcId);
                $citation .= "<tr>
                            <td>";
                !empty($c->subSrcId) ? $citation .= "c -" . $c->subSrcId : null; 
                $citation .= "</td>
                              <td>";
                !empty($c->chNo) ?  $citation .= $c->chNo : null;
                $citation .= "</td>
                              <td>";
                if(!empty($c->authors)){
                    $authors = $c->authors;
                }else{
                    $authors = [];
                }
        	    $i = 1;
                $length = count($authors);
                foreach($authors as $a){
                    if($i == $length){
                        if($i > 1){
                            $citation .= " and " . $a . ". ";
                        }else{
                            $citation .= $a . ". ";
                        }
                    }else{
                        $citation .= $a . ", ";
                        }
                            $i++;
                }
    
                !empty($book->year) ?  $citation .= $book->year . ". " : null;
                !empty($c->title) ?  $citation .= "\"" . $c->title . "\". " : null;
            
                $citation .= "In: ";
                $i = 1;
                $length = count($editors);
                    foreach($editors as $e){
                        if($i == $length){
                            if($i > 1){
                                $citation .= $e . ", editors. ";
                            }else{
                                $citation .= $e . ", editor. ";
                            }
                        }else{
                            $citation .= $e . ", ";
                        }
                        $i++;   
                    }
                    
                    !empty($book->title) ?$citation .= "<em>" . $book->title . "</em>. " : null;
                    !empty($book->location) ? $citation .= $book->location . ": " : null;
                    !empty($book->publisher) ? $citation .= $book->publisher . ". " : null;
                    !empty($c->startPage) ? $citation .= "p " . $c->startPage : null;
                    !empty($c->endPage) ? $citation .= "-" . $c->endPage . "." : null;
                    $citation .= "</td>
                    <td>";
                    !empty($c->srcLocation) ? $citation .= "<a href='". $c->srcLocation . "'>English </a>" : $citation .= "No file attached";
                    $citation .= "</td>
                    </tr>";
            }
                $citation .="</table>";
                }else{
                    $citation = ''; 
                }
                return $citation;    
            }

            static public function insert_authors($book){
                $existingAuthors = Book::findExistingAuthors($book);
      
              foreach($book->authors as $author){
              if(in_array($existingAuthors, $author)){
                $query = "INSERT INTO authors";
                $query .= "(author_type, author_name, source_type, source_id)";
                $query .= " VALUES(";
                $query .=  "'author', '";
                $query .=  $author . "', '";
                $query .= $book->srcType . "', '";
                $query .= $book->srcId;
                $query .= "')";
          
                $result = self::$database->prepare($query);
                $result->execute();
                
                if(!$result) {
                  exit("Database query failed.");
                }
              }else{
                echo "Author " . $author . "exists and was not inserted. <br />";
              }
            }
          }
          static public function insert_editors($book){
            $existingAuthors = Book::findExistingEditors($book);
  
          foreach($book->authors as $author){
          if(in_array($existingAuthors, $author)){
            $query = "INSERT INTO authors";
            $query .= "(author_type, author_name, source_type, source_id)";
            $query .= " VALUES(";
            $query .=  "'editor', '";
            $query .=  $author . "', '";
            $query .= $book->srcType . "', '";
            $query .= $book->srcId;
            $query .= "')";
      
            $result = self::$database->prepare($query);
            $result->execute();
            
            if(!$result) {
              exit("Database query failed.");
            }
          }else{
            echo "Author " . $author . "exists and was not inserted. <br />";
          }
        }
      }
          static public function checkIfSrcExists($source){
            $query = "SELECT * ";
            $query .= " FROM sources ";
            $query .= " WHERE title= '" . $source->title. "'";
            $query .= " AND year = '" . $source->year. "'";
            $query .= " AND srcType = 'b'";  
            return self::find_by_sql($query);
          }
          static public function findExistingAuthors($books){
            $sql = "SELECT * ";
            $sql .= "FROM authors ";
            $sql .= "WHERE source_type ='b' ";
            $sql .= "AND source_id = '". $books->srcId . "' ";
            $sql .= "AND author_type='author'";
      
           $result = self::$database->prepare($sql);
            $result->execute();
            if(!$result) {
              exit("Database query failed.");
            }
            $result->setFetchMode(PDO::FETCH_ASSOC); 
            $existingAuthors = [];
            while($record = $result->fetch()) {
                  $existingAuthors = $record['author_name'];
            }
            return $existingAuthors;
          }

          public function getSrcID(){
            $sql = "SELECT MAX(srcId) AS id ";
            $sql .= "FROM sources ";
              $sql .= "WHERE srcType ='b'";
           $result = self::$database->prepare($sql);
            $result->execute();
            if(!$result) {
              exit("Database query failed.");
            }
            $result->setFetchMode(PDO::FETCH_ASSOC); 
            while($record = $result->fetch()) {
                  $srcId = $record['id'];
            }
            return $srcId + 1;
          }

      static public function insertBook($book){
          $query = "INSERT INTO sources";
          $query .= "(srcType, srcId, year, title, publisher, location, srcLocation) ";
          $query .= "VALUES('";
          $query .= $book->srcType . "', '";
          $query .= $book->srcId . "', '";
          $query .= $book->year . "', '";
          $query .= $book->title . "', '";
          $query .= $book->publisher . "', '";
          $query .= $book->location . "', '";
          $query .= $book->srcLocation;
          $query .= "')";
          try{
              $result = self::$database->prepare($query);
          $result->execute();
          if(!$result) {
            exit("Database query failed.");
          }else{
            Book::create_citation($book);
          }
          }catch(PDOException $e){
       echo $e->getMessage();
          }
      }
    }
?>