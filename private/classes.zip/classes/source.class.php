<?php
    class Source{
        //parameters
        public $id;
        public $srcId;
        public $srcType;
        public $title;
        public $srcLocation;
        public $webmasters;
        static protected $database;

        static public function set_database($database) {
            self::$database = $database;
        }
        
        //constructor
        public function __construct($args=[]) {
            $this->id = $args['id'] ?? '';
            $this->title = $args['title'] ?? '';
            $this->srcLocation = $args['srcLocation'] ?? '';
        }
        
        //functions
        static public function findBySql($sql) {
            $result = self::$database->prepare($sql);
            $result->execute();
            
            if(!$result) {
                exit("Database query failed.");
            }
            $result->setFetchMode(PDO::FETCH_ASSOC); 
            // results into objects
            $object_array = [];
            while($record = $result->fetch()) {
                $object_array[] = self::instantiate($record);
            }  
            $result=null;
            return $object_array;
        }

        static public function findBySqlCount($sql) {
            $result = self::$database->prepare($sql);
            $result->execute();
            if(!$result) {
                exit("Database query failed.");
            }
            // results into value
            $count = $result->fetchColumn();
            return $count;
        }

        static protected function instantiate($record) {
            $object = new self;
            // Could manually assign values to properties
            // but automatically assignment is easier and re-usable
            foreach($record as $property => $value) {
                if(property_exists($object, $property)) {
                    $object->$property = $value;
                }
            }
            return $object;
        }

        //SQL queries
        static public function countSources(){
            $query = "SELECT count(*) FROM sources";
            $total = self::findBySqlCount($query);
            return $total;
        }
        
        static public function getAllTitles(){
            $query = "SELECT DISTINCT title FROM sources";
            $result = self::$database->prepare($query);
            $result->execute();
            if(!$result) {
                exit("Database query failed.");
            }     
            $result->setFetchMode(PDO::FETCH_ASSOC); 
            // results into objects
            $titles = [];
            while($record = $result->fetch()) {
                array_push($titles, $record['title']);
            }      
             return $titles;
        }
        static public function getAllAuthors(){
            $query = "SELECT DISTINCT author_name FROM authors";
            $result = self::$database->prepare($query);
            $result->execute();
            if(!$result) {
                exit("Database query failed.");
            }     
            $result->setFetchMode(PDO::FETCH_ASSOC); 
            // results into objects
            $authors = [];
            while($record = $result->fetch()) {
                array_push($authors, $record['author_name']);
            }      
             return $authors;
        }
        //function to get sources within a range of source IDs (needed for record list in index.php)
        static public function find_all_sources_by_limit($start, $limit){    
            $query =  "SELECT * ";
            $query .= " FROM sources";
            $query .= " ORDER BY id ASC";
            $query .= " Limit " . $start .", " . $limit;
            $obj_array = self::findBySql($query);
            if(!empty($obj_array)) {
                return $obj_array;
            } else {
                return false;
            }
        }
        
        static public function createSourcePreview($source){
            $html = '<br />
            <input type="button" id="btnSourcePreview_'. $source->id . '" value="+"
             onclick=\'toggleShow("SourcePreview_'.$source->id. '")\' />
            Source Preview<br />
            <div id="SourcePreview_'.$source->id . '" style="display: none">
                <p>' . $source->srcLocation . '</p>
                <br />
                <br />
                <iframe src="https://docs.google.com/viewer?url=https://localhost/jomon/'. 
                  $source->srcLocation .'&embedded=true" style="width:600px; height:500px;" 
                  frameborder="0"></iframe>
            </div>';
            return $html;
        } 

    }
?>