<?php

class Article extends Source{
    //parameters
    public $id;
    public $year;
    public $journal;
    public $volume;
    public $issue;
    public $authors;
   // public $srcLocation;

      //functions
  static public function findBySql($sql) {
      $result = self::$database->prepare($sql);
      $result->execute();
      
      if(!$result) {
        exit("Database query failed.");
      }
      $result->setFetchMode(PDO::FETCH_ASSOC); 
      // results into objects
      $object_array = [];
      while($record = $result->fetch()) {
        $object_array[] = self::instantiate($record);
      }  
      $result=null;
      return $object_array;
    }

    static public function findBySqlCount($sql) {
      $result = self::$database->prepare($sql);
      $result->execute();
      if(!$result) {
        exit("Database query failed.");
      }
      // results into value
      $count = $result->fetchColumn();
      return $count;
    }

    static protected function instantiate($record) {
        $object = new self;
        // Could manually assign values to properties
        // but automatically assignment is easier and re-usable
        foreach($record as $property => $value) {
        if(property_exists($object, $property)) {
            $object->$property = $value;
        }
        }
        return $object;
    }
    //constructor
    public function __construct($args=[]) {
        parent::__construct($args);  
        $this->srcType = 'a';
        $this->year = $args['year'] ?? '';
        $this->journal = $args['journal'] ?? '';
        $this->volume = $args['volume'] ?? '';
        $this->issue = $args['issue'] ?? '';
        $this->authors = $args['authors'] ?? [];
        //$this->srcLocation = h($args['srcLocation']) ?? '';
        $this->srcId = $this->getSrcID();

    }
    // Database methods
    static public function findAll() {
      $sql = "SELECT id, srcType, srcId, year, title,
      journal, volume, issue, srcLocation";
      return self::findBySql($sql);
    }

    static public function findById($srcType, $srcId) {
      $query = "SELECT id, srcType, srcId, year, title,
                journal, volume, issue, srcLocation";
      $query .= " FROM sources";
      $query .= " WHERE srcId='" . $srcId . "'";
      $query .= " AND srcType='" . $srcType . "'";
      $obj_array = self::findBySql($query);
      if(!empty($obj_array)) {
        return array_shift($obj_array);
      } else {
        return false;
      }
    }
      
    static public function findByTitle($title) {
      $query = "SELECT * ";
      $query .= " FROM sources ";
      $query .= " WHERE title= '" . $title. "'";
      $query .= " AND srcType = 'a'";  
      return self::findBySql($query);
    }
    
    
    static public function deleteById($srcId) {
      $query = "DELETE ";
      $query .= " FROM sources ";
      $query .= " WHERE srcId= '" . $srcId. "'";
      $query .= " AND srcType = 'a'";  
       $result = self::$database->prepare($query);
      $result->execute();
      
      if(!$result) {
        exit("Database query failed.");
      }
    }
    static public function updateSource($source, $update) {
      $attribute_pairs = [];
      foreach($update as $key => $value) {
        $attribute_pairs[] = "{$key}='{$value}'";
      }
      $query = "UPDATE sources SET ";
      $query .= join(', ', $attribute_pairs);      
      $query .= " WHERE srcType = '" . $source->srcType . "'";
      $query .= " AND srcid = '". $source->srcId . "'"; 

      $result = self::$database->prepare($query);
      $result->execute();
      
      if(!$result) {
        exit("Database query failed.");
      }
    }
    static public function insertAuthors($source){
          $existingAuthors = Article::findExistingAuthors($source);

    	foreach($source->authors as $author){
        if(in_array($existingAuthors, $author)){
          $query = "INSERT INTO authors";
          $query .= "(author_type, author_name, source_type, source_id)";
          $query .= " VALUES(";
          $query .=  "'author', '";
          $query .=  $author . "', '";
          $query .= $source->srcType . "', '";
          $query .= $source->srcId;
          $query .= "')";
    
          $result = self::$database->prepare($query);
          $result->execute();
          
          if(!$result) {
            exit("Database query failed.");
          }
        }else{
          echo "Author " . $author . "exists and was not inserted. <br />";
        }
      }
    }
    
    static public function checkIfSrcExists($source){
      $query = "SELECT * ";
      $query .= " FROM sources ";
      $query .= " WHERE title= '" . $source->title. "'";
      $query .= " AND journal = '" . $source->journal. "'";
      $query .= " AND year= '" . $source->year. "'";
      $query .= " AND srcType = 'a'";  
      return self::findBySql($query);
    }
    static public function findExistingAuthors($articles){
      $sql = "SELECT * ";
      $sql .= "FROM authors ";
      $sql .= "WHERE source_type ='a' ";
      $sql .= "AND source_id = '". $articles->srcId . "' ";
      $sql .= "AND author_type='author'";

	 $result = self::$database->prepare($sql);
      $result->execute();
      if(!$result) {
        exit("Database query failed.");
      }
      $result->setFetchMode(PDO::FETCH_ASSOC); 
      $existingAuthors = [];
      while($record = $result->fetch()) {
		    $existingAuthors = $record['author_name'];
      }
      return $existingAuthors;
    }
    public function getSrcID(){
      $sql = "SELECT MAX(srcId) AS id ";
      $sql .= "FROM sources ";
    	$sql .= "WHERE srcType ='a'";
	 $result = self::$database->prepare($sql);
      $result->execute();
      if(!$result) {
        exit("Database query failed.");
      }
      $result->setFetchMode(PDO::FETCH_ASSOC); 
      while($record = $result->fetch()) {
		    $srcId = $record['id'];
      }
      return $srcId + 1;
    }
static public function insert($source){
	$query = "INSERT INTO sources";
	$query .= "(srcType, srcId, year, title, journal, volume, issue, srcLocation) ";
	$query .= "VALUES('";
	$query .= $source->srcType . "', '";
	$query .= $source->srcId . "', '";
	$query .= $source->year . "', '";
	$query .= $source->title . "', '";
	$query .= $source->journal . "', '";
	$query .= $source->volume . "', '";
	$query .= $source->issue . "', '";
	$query .= $source->srcLocation;
	$query .= "')";
	try{
		$result = self::$database->prepare($query);
    $result->execute();
    if(!$result) {
      exit("Database query failed.");
    }else{
      Article::createCitation($source);
    }
	}catch(PDOException $e){
 echo $e->getMessage();
	}
}
public function clearAuthors(){
  $this->authors = []; 
}
static public function getAuthors($source, $srcType, $srcId){
	$authors =[];
	$sql = "SELECT * ";
	$sql .= "FROM authors ";
	$sql .= "WHERE source_id = '" . $srcId . "'";
  $sql .= " AND source_type= '" . $srcType . "'";
  $sql .= " AND author_type = 'author'";

	 $result = self::$database->prepare($sql);
      $result->execute();
      
      if(!$result) {
        exit("Database query failed.");
      }
      $result->setFetchMode(PDO::FETCH_ASSOC); 
      while($record = $result->fetch()) {
		array_push($authors, $record['author_name']);
	}
	$source->authors = $authors;
}
    static public function createCitation($source){  
        $citation = "";
        if(!empty($source->authors)){
        	$authors = $source->authors;
        	$i = 1;
        	$length = count($authors);
        	foreach($authors as $a){
        		if($i == $length){
         			$citation .= $a . ". ";
         		}else{
         			$citation .= $a . ", ";
         			}
         				$i++;
        	}
        }
        !empty($source->year) ?  $citation .= $source->year . ". " : null;
        !empty($source->title) ?$citation .= $source->title . ". " : null;
        !empty($source->journal) ? $citation .= "<em>" . $source->journal . "</em>. " : null;
        !empty($source->volume) ? $citation .= "vol " . $source->volume : null;
        !empty($source->issue) ? $citation .= "(" . $source->issue . ")" : null;
        $citation .= ".";
        return $citation;
      }

      

      static public function checkIfDirectoryExists($target_dir){
        if(!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
      }

      static public function uploadSource($source, $file){
        //create directory to store files if the directory does not exist
        $target_dir = "../../source/article/";
        Article::checkIfDirectoryExists('../../source');
        Article::checkIfDirectoryExists('../../source/article');
        if(!empty($source->journal)){
          $target_dir .= $source->journal;
          Article::checkIfDirectoryExists($target_dir);
          $target_dir .= '/';
        }else{
          $target_dir .= "unknownJournal";
          Article::checkIfDirectoryExists($target_dir);
          $target_dir .= '/';
        }
        if(!empty($article->year)){
          $target_dir .= $article->year;
          Article::checkIfDirectoryExists($target_dir);
          $target_dir .= '/';
        }else{
          $target_dir .= "unknownYear";
          Article::checkIfDirectoryExists($target_dir);
          $target_dir .= '/';
        }
        if(!empty($article->volume)){
          $target_dir .= $article->volume;
          Article::checkIfDirectoryExists($target_dir);
          $target_dir .= '/';
        }else{
          $target_dir .= "unknownVolume";
          Article::checkIfDirectoryExists($target_dir);
          $target_dir .= '/';
        }
        if(!empty($article->issue)){
          $target_dir .= $article->issue;
          Article::checkIfDirectoryExists($target_dir);
          $target_dir .= '/';
        }else{
          $target_dir .= "unknownIssue";
          Article::checkIfDirectoryExists($target_dir);
          $target_dir .= '/';
        }
        if($file['name'] != "") {
          // No file was selected for upload, your (re)action goes here
          //get the file extension from the uploaded File name
          $tmp = explode(".", $file["name"]);
          $fileExtension = end($tmp); 
          //Set source location in Article Object
          $newFileName = $article->title; 
          $target_file = $target_dir . $newFileName . "." . $fileExtension;
          $source->srcLocation = $target_file;
          $uploadOk = 1; 
          $fileType = strtolower($fileExtension);
          // Check if valid filetype
          if ($fileType != 'pdf') {
            echo "All uploaded articles must be .pdf files. File cannot be uploaded";
            $uploadOk = 3;
          }
          // Check if file already exists
          if (file_exists($target_file)) {
            echo "Sorry, file already exists.";
            $uploadOk = 2;
          }
          //Upload the file
          // Check if $uploadOk is set to 0 by an error
          if ($uploadOk != 1) {
            echo "Sorry, your file was not uploaded.<br />";
            switch($uploadOk){
              case 2: 
                echo "Form Handling Error 2: 
                    <br />File already exists.";
                break;
              case 3: 
                echo "Form Handling Error 3:<br />
                  Invalid File Type: All uploaded articles must be .pdf files. File cannot be uploaded";
                break; 
              case 1:
                break; 
              default:
                echo "Form Handling Error: <br />
                    An unknown error occurred"; 
            }
        // if everything is ok, try to upload file
        } else {
          if (move_uploaded_file($file["tmp_name"], $target_file)) {
            echo "The file ". $newFileName. $fileExtension .
                " has been uploaded.<br />
                <table class = 'table'>
                <tr>
                <td>File Name: </td> 
                <td>".$target_file . "</td>
                </tr>
                <tr>
                <td>File Type: </td>
                <td>".$file["type"] . "</td>
                </tr>
                <tr>
                <td>File Size: </td>
                <td>".$file["size"] . "</td>
                </tr>
                </table>";
          } else {
            echo "There was an server error uploading your file. <br/>
                PHP Error: " .$file["error"];
          }
        }
      }else{
        echo "Error: No file was attached to be uploaded.";
      }
    }
  }

?>